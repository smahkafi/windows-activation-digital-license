<h1>Windows++</h1>

<h1><b>This is my first ever project. I have spent a lot of time in this ,  Made with ❤<b></h1>

The tools handles Windows Activation related stuff.

<h2><b>Features:</b> </h2>
<h3>Activate Windows 10 with a Digital License which can be linked with Microsoft Account<h3>
<h3>Backup All Activation Information so that it can be used after a fresh installation<h3>
<h3>Check Activation Status & Activation Type<h3>
<h3><b>No Spam! No Virus! But defender may show it as a virus because I don't have capabilites to Sign this program & that's why I had to temporarily bypass Execution Policy. <br> No need to panic! All changes will automatically be reverted back to Windows Default to ensure maximum security.<b><h3>
  
